export class JsonFile {
    constructor(filename) {
        this.filename = filename;
    }

    async save(data) {
        try {
            const response = await fetch(`http://localhost:3000/archivos/${this.filename}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(data)
            });
            if (!response.ok) {
                throw new Error('Error saving data');
            }
        } catch (error) {
            console.error('Error saving data:', error);
        }
    }

    async read() {
        try {
            const response = await fetch(`http://localhost:3000/archivos/${this.filename}`);
            if (!response.ok) {
                throw new Error('Error reading data');
            }
            const data = await response.json();
            return data;
        } catch (error) {
            console.error('Error reading data:', error);
            return [];
        }
    }

    async find(atributo, buscado) {
        try {
            const datas = await this.read();
            return datas.filter(item => item[atributo] === buscado);
        } catch (error) {
            console.error('Error finding data:', error);
            return [];
        }
    }

    async delete(atributo, buscado) {
        try {
            const itemsToDelete = await this.find(atributo, buscado);
            if (itemsToDelete.length > 0) {
                let datas = await this.read();
                datas = datas.filter(data => !itemsToDelete.some(item => item[atributo] === data[atributo]));
                await this.save(datas);
                return "Elementos eliminados exitosamente.";
            } else {
                return "No se encontraron elementos para eliminar.";
            }
        } catch (error) {
            console.error('Error deleting data:', error);
            throw error;
        }
    }
}

// export class JsonFile {
//     constructor(filename) {
//         this.filename = filename;
//     }

//     save(data) {
//         try {
//             localStorage.setItem(this.filename, JSON.stringify(data));
//         } catch (error) {
//             console.error('Error saving data:', error);
//         }
//     }

//     read() {
//         try {
//             const fileContent = localStorage.getItem(this.filename);
//             return fileContent ? JSON.parse(fileContent) : [];
//         } catch (error) {
//             console.error('Error reading data:', error);
//             return [];
//         }
//     }

//     find(atributo, buscado) {
//         try {
//             const datas = this.read();
//             return datas.filter(item => item[atributo] === buscado);
//         } catch (error) {
//             console.error('Error finding data:', error);
//             return [];
//         }
//     }

//     delete(atributo, buscado) {
//         try {
//             const itemsToDelete = this.find(atributo, buscado);
//             if (itemsToDelete.length > 0) {
//                 let datas = this.read();
//                 datas = datas.filter(data => !itemsToDelete.some(item => item[atributo] === data[atributo]));
//                 this.save(datas);
//                 return "Elementos eliminados exitosamente.";
//             } else {
//                 return "No se encontraron elementos para eliminar.";
//             }
//         } catch (error) {
//             console.error('Error deleting data:', error);
//             throw error;
//         }
//     }

// }
