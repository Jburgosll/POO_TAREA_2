const express = require('express');
const cors = require('cors')
const bodyParser = require('body-parser');
const fs = require('fs');
const path = require('path');
const app = express();
const port = 3000;
app.use(cors()); 
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'menu'))); // Sirviendo archivos estáticos desde 'menu'

// Función para leer un archivo JSON
const readJsonFile = (filePath) => {
    return new Promise((resolve, reject) => {
        fs.readFile(filePath, 'utf8', (err, data) => {
            if (err) {
                reject(err);
            } else {
                resolve(JSON.parse(data));
            }
        });
    });
};

// Función para escribir en un archivo JSON
const writeJsonFile = (filePath, data) => {
    return new Promise((resolve, reject) => {
        fs.writeFile(filePath, JSON.stringify(data, null, 2), 'utf8', (err) => {
            if (err) {
                reject(err);
            } else {
                resolve();
            }
        });
    });
};

// Endpoint para obtener datos de un archivo JSON
app.get('/archivos/:filename', async (req, res) => {
    try {
        const data = await readJsonFile(`./archivos/${req.params.filename}`);
        res.json(data);
    } catch (err) {
        console.error('Error reading file:', err);
        res.status(500).send('Error reading file');
    }
});

// Endpoint para actualizar (sobrescribir) un archivo JSON
app.post('/archivos/:filename', async (req, res) => {
    try {
        await writeJsonFile(`./archivos/${req.params.filename}`, req.body);
        res.send('File successfully updated');
    } catch (err) {
        console.error('Error writing file:', err);
        res.status(500).send('Error writing file');
    }
});

// Endpoint para eliminar un archivo JSON
app.delete('/archivos/:filename', (req, res) => {
    fs.unlink(`./archivos/${req.params.filename}`, (err) => {
        if (err) {
            console.error('Error deleting file:', err);
            res.status(500).send('Error deleting file');
        } else {
            res.send('File successfully deleted');
        }
    });
});

// Servir el archivo HTML principal
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'menu', 'htmltesting.html'));
});

// Manejador de errores genérico
app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    res.status(500).send('Internal Server Error');
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});

